# Self-Assessment for Hands-On 1

## Group Members
- Daniel Martín Rojo (GitHub: ITsDIDI3 )
- Francisco Chicote Martín (GitHub: fran2410 )


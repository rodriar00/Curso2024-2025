5
    Analysis
    Ontology
        - The XML schema datatypes must be written in lowercase
        - Datatype properties are incorrectly defined as object properties.
    RDF data
        - The values of xsd:time are not correct (or that is not the proper datatype).
        - The values of sosa:hasFeatureOfInterest are not correct.
    Take into account that the review has been performed over a previous version of the hands-on. Some of the defects found may have been already fixed.
